<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('paradas', function (Blueprint $table) {
            $table->integer('id_paradas', true);
            $table->string('nombre_parada', 100);
            $table->string('sentido', 100);
            $table->geometry('lat_long', 'point');
            $table->unsignedBigInteger('id_ruta')->nullable()->index('id_ruta');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('paradas');
    }
};
